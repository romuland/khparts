<?php
$compress_stamp=1353395767;
?>
