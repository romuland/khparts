<?php
/**
*
* Show the products in a category
*
* @package	VirtueMart
* @subpackage
* @todo add pagination
* @link http://www.virtuemart.net
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
*/

//vmdebug('$this->category',$this->category);
vmdebug('$this->category '.$this->category->category_name);
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
JHTML::_( 'behavior.modal' );
/* javascript for list Slide
  Only here for the order list
  can be changed by the template maker
*/
$js = "
jQuery(document).ready(function () {
	jQuery('.orderlistcontainer').hover(
		function() { jQuery(this).find('.orderlist').stop().show()},
		function() { jQuery(this).find('.orderlist').stop().hide()}
	)
});
";

$document = JFactory::getDocument();
$document->addScriptDeclaration($js);

/*$edit_link = '';
if(!class_exists('Permissions')) require(JPATH_VM_ADMINISTRATOR.DS.'helpers'.DS.'permissions.php');
if (Permissions::getInstance()->check("admin,storeadmin")) {
	$edit_link = '<a href="'.JURI::root().'index.php?option=com_virtuemart&tmpl=component&view=category&task=edit&virtuemart_category_id='.$this->category->virtuemart_category_id.'">
		'.JHTML::_('image', 'images/M_images/edit.png', JText::_('COM_VIRTUEMART_PRODUCT_FORM_EDIT_PRODUCT'), array('width' => 16, 'height' => 16, 'border' => 0)).'</a>';
}

echo $edit_link; */

 /*
<div id="zt-breadcrumbs-inner">
											<!--BEGIN Search Box 
<script type="text/javascript">
$(function(){
  $("#mod_virtuemart_search").keyup(function(){
     var search = $("#mod_virtuemart_search").val();
     $.ajax({
       type: "POST",
       url: "search.php",
       data: {"search": search},
       cache: false,                                
       success: function(response){
          $("#resSearch").html(response);
       }
     });
     return false;
   });
});
</script>
-->

/*
$search_box = '<form action="" method="get"><div class="searchhor">';
$search_box.='<input autocomplete="off" style="height:16px;vertical-align :middle;"';
$search_box.=' name="keyword" id="mod_virtuemart_search" maxlength="100" alt="Search" class="inputboxhor" size="100" value="Каталожный номер"';
$search_box.=' onblur="if(this.value=='."''".') this.value='."'Каталожный номер';" onfocus="if(this.value=='Каталожный номер') this.value='';" onkeyup="ajaxSearch(this.value,'',event);" onkeydown="prevent(event)" onkeypress="prevent(event)" type="text"><div id="resSearch" class="ajax_list"></div><input style="vertical-align :middle;height:20px;margin: -22px; " value="Search" class="buttonsearch" src="http://khparts.ru/components/com_virtuemart/assets/images/vmgeneral/lupa.png" onclick="this.form.keyword.focus();" type="image"></div>
		<input name="limitstart" value="0" type="hidden">
		<input name="option" value="com_virtuemart" type="hidden">
		<input name="view" value="category" type="hidden">
	  </form>

<!-- End Search Box -->
										</div>*/
                                        
                                      
if ( empty($this->keyword) ) {
	?>
	<div class="category_description">
	<?php echo $this->category->category_description ; ?>
     <?php /*echo JHTML::link('/price', 'Вернутья в каталог'); */?>
	</div>
	<?php
}

/* Show child categories */

if ( VmConfig::get('showCategory',1) and empty($this->keyword) && empty($this->products)) {
	if ($this->category->haschildren) {

		// Category and Columns Counter
		$iCol = 1;
		$iCategory = 1;

		// Calculating Categories Per Row
		$categories_per_row = VmConfig::get ( 'categories_per_row', 3 );
		$category_cellwidth = ' width'.floor ( 100 / $categories_per_row );

		// Separator
		$verticalseparator = " vertical-separator";
		?>

		<div class="category-view">

		<?php // Start the Output
		if(!empty($this->category->children)){
		foreach ( $this->category->children as $category ) {

			// Show the horizontal seperator
			if ($iCol == 1 && $iCategory > $categories_per_row) { ?>
			<div class="horizontal-separator"></div>
			<?php }

			// this is an indicator wether a row needs to be opened or not
			if ($iCol == 1) { ?>
			<div class="row">
			<?php }

			// Show the vertical seperator
			if ($iCategory == $categories_per_row or $iCategory % $categories_per_row == 0) {
				$show_vertical_separator = ' ';
			} else {
				$show_vertical_separator = $verticalseparator;
			}

			// Category Link
			$caturl = JRoute::_ ( 'index.php?option=com_virtuemart&view=category&virtuemart_category_id=' . $category->virtuemart_category_id );

				// Show Category ?>
				<div class="category floatleft<?php echo $category_cellwidth . $show_vertical_separator ?>">
					<div class="spacer">
						<h2>
							<a href="<?php echo $caturl ?>" title="<?php echo $category->category_name ?>">
							<?php 
								echo $category->category_name ?>
                               
							<br />
							<?php // if ($category->ids) {
								echo $category->images[0]->displayMediaThumb("",false);
							//} ?>
							</a>
						</h2>
					</div>
				</div>
			<?php
			$iCategory ++;

		// Do we need to close the current row now?
		if ($iCol == $categories_per_row) { ?>
		<div class="clear"></div>
		</div>
			<?php
			$iCol = 1;
		} else {
			$iCol ++;
		}
	}
	}
	// Do we need a final closing row tag?
	if ($iCol != 1) { ?>
		<div class="clear"></div>
		</div>
	<?php } ?>
</div>

<?php }
}
?>
<div class="browse-view">
    <?php
if (!empty($this->keyword)) {
	?>
	<?php echo "<span style='font-size:larger'>Вы искали:&nbsp<strong>".$this->keyword."</strong></span>"?> 
	<?php
} ?>
 		<?php if ($this->search !==null ) { ?>
		    <form action="<?php echo JRoute::_('index.php?option=com_virtuemart&view=category&limitstart=0&virtuemart_category_id='.$this->category->virtuemart_category_id ); ?>" method="get">

		    <!--BEGIN Search Box --><div class="virtuemart_search">
			
		   <?php /*echo $this->searchcustomvalues */?> 
		   <!-- <input name="keyword" class="inputbox" type="text" size="20" value="<?php echo $this->keyword ?>" />-->
		   <!-- <input type="submit" value="<?php echo JText::_('COM_VIRTUEMART_SEARCH') ?>" class="button" onclick="this.form.keyword.focus();"/>-->
		    </div>
				    <input type="hidden" name="search" value="true" />
				    <input type="hidden" name="view" value="category" />

		    </form>
		<!-- End Search Box -->
		<?php } ?>

<?php // Show child categories
if (!empty($this->products)) {
?>
			<div class="orderby-displaynumber">
             	<!--Сортировка \administrator\components\com_virtuemart\models\product.php-->
				<div class="width70 floatleft">
					<?php echo $this->orderByList['orderby']; ?>
				</div>
                <!--Счетчик сколько показывать \administrator\components\com_virtuemart\helpers\vmmodel.php-->
				<div class="width30 floatright display-number"><?php echo $this->vmPagination->getResultsCounter();?><br/><?php echo $this->vmPagination->getLimitBox(); ?></div>
                <!--Ссылки на страницы-->
				<div class="vm-pagination">
					<?php echo $this->vmPagination->getPagesLinks(); ?>
                     <!--Количество страницы -->
					<!--<span style="float:right"><?php /*echo $this->vmPagination->getPagesCounter(); */?></span>-->
				</div>

			<div class="clear"></div>
			</div> <!-- end of orderby-displaynumber -->

<?php
// Category and Columns Counter
$iBrowseCol = 1;
$iBrowseProduct = 1;

// Calculating Products Per Row
$BrowseProducts_per_row = $this->perRow;
$Browsecellwidth = ' width'.floor ( 100 / $BrowseProducts_per_row );

// Separator
$verticalseparator = " vertical-separator";

// Count products
$BrowseTotalProducts = 0;
foreach ( $this->products as $product ) {
   $BrowseTotalProducts ++;
}
if ($BrowseTotalProducts > 0){
			echo "<table class='table_cat'";
            echo "<tr>";
			//echo "<td class='table_cat_margin'>";
            echo "<td class='table_cat_name table_cat_title'>Наименование</td>";
			echo "<td class='table_cat_mf table_cat_title'>Произ-<br />водитель</td>";
			if ($this->category->category_name == 'Сопутствующие товары') echo "<td class='table_cat_car table_cat_title'>Марка</td>";
   			else echo "<td class='table_cat_car table_cat_title'>А/м</td>";
			echo "<td class='table_cat_num table_cat_title'>Номер</td>";
			echo "<td class='table_cat_price table_cat_title'>Цена</td>";
			echo "<td class='table_cat_count table_cat_title'>Наличие</td>";
			echo "</tr>";
			echo "</table>";
			echo "<div class='horizontal-separator'></div>";
}else{
	echo "Нет запчастей для выбранной ".$this->category->category_name;
}
// Start the Output
foreach ( $this->products as $product ) {

	// Show the horizontal seperator
	if ($iBrowseCol == 1 && $iBrowseProduct > $BrowseProducts_per_row) { ?>
	<div class="horizontal-separator"></div>
	<?php }

	// this is an indicator wether a row needs to be opened or not
	if ($iBrowseCol == 1) { ?>
	<div class="row">
	<?php }

	// Show the vertical seperator
	if ($iBrowseProduct == $BrowseProducts_per_row or $iBrowseProduct % $BrowseProducts_per_row == 0) {
		$show_vertical_separator = ' ';
	} else {
		$show_vertical_separator = $verticalseparator;
	}

		// Show Products ?>
		<div class="product floatleft<?php 

		echo $Browsecellwidth . $show_vertical_separator ?>">

			<div class="spacer">
            
<?php      

	$car_name = '';
	foreach($product->customfields as $field){
		if($field->custom_title == "Car Name"){
			$car_name = $field->custom_value;
		}
	}
$car_name = str_replace("~", "<br />", $car_name);

?>
			<table>
            <tr>
           		<!--<td class='table_cat_margin'/>-->
                <td class='table_cat_name'>
					<?php echo JHTML::link($product->link, $product->product_name); ?></h2>
				</td>
                <td class='table_cat_mf'>
                	<?php echo $product->mf_name;?>
                </td>                       
                <td class='table_cat_car'>
                	<?php 
					echo $car_name;
/*					echo $product->category_name;*/
					?>
                </td>                
                <td class='table_cat_num'>
                	<?php echo $product->product_sku;?>
                </td>
                <td class = 'table_cat_price'>
                
					<?php
					/*D:\Site\home\romuland.loc\www\administrator\components\com_virtuemart\helpers\currencydisplay.php*/
					if ($this->show_prices == '1') {
						if( $product->product_unit && VmConfig::get('vm_price_show_packaging_pricelabel')) {
							echo "<strong>". JText::_('COM_VIRTUEMART_CART_PRICE_PER_UNIT').' ('.$product->product_unit."):</strong>";
						}
						if(empty($product->prices) and VmConfig::get('askprice',1) and empty($product->images[0]->file_is_downloadable) ){
							echo JText::_('COM_VIRTUEMART_PRODUCT_ASKPRICE');
						}
						echo $this->currency->createPriceDiv('basePrice','COM_VIRTUEMART_PRODUCT_SALESPRICE',$product->prices);
					} ?>
				</td>              
            	<td class='table_cat_count'>
					<div class="paddingtop8">
						<span class="vmicon vm2-<?php echo $product->stock->stock_level ?>" title="<?php 
						if ($product->stock->stock_level == "nostock") echo "Под заказ";
						elseif ($product->stock->stock_level == "lowstock") echo "Мало на складе";
						else echo "Есть";
						//$product->stock->stock_tip  - непонятно как поменять
						?>"></span>
					</div>
				</td>  
                
                <td>
					<p>
					<?php // Product Details Button
					/*echo JHTML::link($product->link, JText::_('COM_VIRTUEMART_PRODUCT_DETAILS'), array('title' => $product->product_name,'class' => 'product-details'));*/
					?>
					</p>

				<!--</div>-->
			</td>
          
            </tr>
            </table>
			<div class="clear"></div>
			</div><!-- end of spacer -->
		</div> <!-- end of product -->
	<?php

   // Do we need to close the current row now?
   if ($iBrowseCol == $BrowseProducts_per_row || $iBrowseProduct == $BrowseTotalProducts) {?>
   <div class="clear"></div>
   </div> <!-- end of row -->
      <?php
      $iBrowseCol = 1;
   } else {
      $iBrowseCol ++;
   }

   $iBrowseProduct ++;
} // end of foreach ( $this->products as $product )
// Do we need a final closing row tag?
if ($iBrowseCol != 1) { ?>
	<div class="clear"></div>

<?php
}
?>
<!-- /div removed valerie -->
	<div class="vm-pagination">
	<?php echo $this->vmPagination->getPagesLinks(); ?>
     <!--Количество страницы -->
	 <!--<span style="float:right"><?php /*echo $this->vmPagination->getPagesCounter(); */?></span>-->
    </div>
<!-- /div removed valerie -->
<?php } elseif ($this->search !==null ) {
	echo "<p><h4>".JText::_('COM_VIRTUEMART_NO_RESULT').($this->keyword? ' : ('. $this->keyword. ')' : '')."</h4></p>";
	}
	//echo "<p>".JHTML::link('/price', 'Вернутья в каталог')."</p>";
?>
</div><!-- end browse-view -->